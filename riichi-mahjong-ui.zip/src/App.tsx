/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Table } from './components/Mahjong/Table';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950">
      <Table />
    </div>
  );
}
