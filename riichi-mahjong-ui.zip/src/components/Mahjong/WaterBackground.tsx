import React, { useEffect, useRef } from 'react';

interface Ripple {
  x: number;
  y: number;
  radius: number;
  alpha: number;
}

export const WaterBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ripplesRef = useRef<Ripple[]>([]);
  const timeRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', resize);
    resize();

    let animationFrameId: number;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      timeRef.current += 0.02;

      // 1. Draw gentle background flow (cartoon water lines)
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.lineWidth = 6;
      ctx.lineCap = 'round';
      
      for (let i = -50; i < canvas.height + 50; i += 80) {
        ctx.beginPath();
        for (let j = 0; j < canvas.width + 50; j += 40) {
          const yOffset = Math.sin(j * 0.005 + timeRef.current + i) * 20;
          if (j === 0) ctx.moveTo(j, i + yOffset);
          else ctx.lineTo(j, i + yOffset);
        }
        ctx.stroke();
      }

      // 2. Draw mouse ripples
      const ripples = ripplesRef.current;
      for (let i = ripples.length - 1; i >= 0; i--) {
        const r = ripples[i];
        
        ctx.beginPath();
        ctx.arc(r.x, r.y, r.radius, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(255, 255, 255, ${r.alpha})`;
        ctx.lineWidth = 4;
        ctx.stroke();
        
        // Inner ripple
        if (r.radius > 30) {
          ctx.beginPath();
          ctx.arc(r.x, r.y, r.radius - 30, 0, Math.PI * 2);
          ctx.strokeStyle = `rgba(255, 255, 255, ${r.alpha * 0.4})`;
          ctx.lineWidth = 2;
          ctx.stroke();
        }

        r.radius += 2.5;
        r.alpha -= 0.015;

        if (r.alpha <= 0) {
          ripples.splice(i, 1);
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };
    render();

    let lastSpawn = 0;
    const handleMouseMove = (e: MouseEvent) => {
      const now = Date.now();
      if (now - lastSpawn > 80) { // Limit ripple spawn rate
        ripplesRef.current.push({
          x: e.clientX,
          y: e.clientY,
          radius: 0,
          alpha: 0.8,
        });
        lastSpawn = now;
      }
    };

    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none absolute inset-0 z-0 h-full w-full mix-blend-overlay opacity-60"
    />
  );
};
