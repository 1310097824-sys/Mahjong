/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Tile } from '@/src/types/mahjong';
import { MahjongTile } from './MahjongTile';

interface RiverProps {
  discards: Tile[];
  orientation?: 'bottom' | 'top' | 'left' | 'right';
}

export const River: React.FC<RiverProps> = ({ discards, orientation = 'bottom' }) => {
  // Riichi Mahjong discards are usually in rows of 6
  const rows = [];
  for (let i = 0; i < discards.length; i += 6) {
    rows.push(discards.slice(i, i + 6));
  }

  return (
    <div className="flex flex-col gap-1">
      {rows.map((row, rowIndex) => (
        <div key={rowIndex} className="flex flex-row gap-1">
          {row.map((tile, tileIndex) => (
            <MahjongTile
              key={`${tile.suit}-${tile.value}-${rowIndex}-${tileIndex}`}
              tile={tile}
              size="sm"
              isDiscarded
            />
          ))}
        </div>
      ))}
    </div>
  );
};
