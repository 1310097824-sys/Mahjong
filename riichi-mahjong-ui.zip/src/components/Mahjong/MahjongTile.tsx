/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { cn } from '@/lib/utils';
import { Tile, Suit } from '@/src/types/mahjong';

interface MahjongTileProps {
  tile: Tile;
  size?: 'sm' | 'md' | 'lg';
  isFaceDown?: boolean;
  isDiscarded?: boolean;
  isRiichi?: boolean;
  onClick?: () => void;
  className?: string;
}

const getTileContent = (tile: Tile) => {
  if (!tile) return '';
  const { suit, value } = tile;
  if (suit === 'z') {
    const honors = ['東', '南', '西', '北', '白', '發', '中'];
    return honors[value - 1] || '';
  }
  
  // For simplicity, we'll use text labels. In a real app, we'd use SVG or images.
  const suitLabels: Record<Suit, string> = {
    m: '萬',
    p: '筒',
    s: '索',
    z: '', // Handled above
  };
  
  return `${value}${suitLabels[suit] || ''}`;
};

const getTileColor = (tile: Tile) => {
  if (!tile) return 'text-slate-800';
  if (tile.suit === 'z') {
    if (tile.value === 6) return 'text-green-600'; // Green dragon
    if (tile.value === 7) return 'text-red-600';   // Red dragon
    return 'text-slate-800';
  }
  if (tile.isRed) return 'text-red-600';
  if (tile.suit === 'm') return 'text-red-700';
  if (tile.suit === 'p') return 'text-blue-700';
  if (tile.suit === 's') return 'text-green-700';
  return 'text-slate-800';
};

export const MahjongTile: React.FC<MahjongTileProps> = ({
  tile,
  size = 'md',
  isFaceDown = false,
  isDiscarded = false,
  isRiichi = false,
  onClick,
  className,
}) => {
  const sizeClasses = {
    sm: 'w-[30px] h-[40px] text-[16px]',
    md: 'w-[40px] h-[56px] text-[20px]',
    lg: 'w-[50px] h-[70px] text-[32px]',
  };

  if (isFaceDown) {
    return (
      <div
        className={cn(
          'relative rounded-lg border-b-[6px] border-r-[2px] border-amber-600 bg-amber-400 shadow-sm transition-transform hover:-translate-y-2',
          sizeClasses[size],
          className
        )}
      />
    );
  }

  return (
    <div
      onClick={onClick}
      className={cn(
        'relative flex cursor-pointer flex-col items-center justify-center rounded-lg border-b-[6px] border-r-[2px] border-tile-side bg-tile-ivory shadow-sm transition-all hover:-translate-y-2 hover:shadow-lg active:translate-y-0 active:border-b-[2px]',
        sizeClasses[size],
        isRiichi && 'rotate-90',
        isDiscarded && 'opacity-90',
        className
      )}
    >
      {/* Tile face */}
      <div className={cn('font-black select-none', getTileColor(tile))}>
        {getTileContent(tile)}
      </div>
    </div>
  );
};
