/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GameState, Tile, Player } from '@/src/types/mahjong';
import { Hand } from './Hand';
import { River } from './River';
import { MahjongTile } from './MahjongTile';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { WaterBackground } from './WaterBackground';

const INITIAL_HAND: Tile[] = [
  { suit: 'm', value: 1 },
  { suit: 'm', value: 2 },
  { suit: 'm', value: 3 },
  { suit: 's', value: 4 },
  { suit: 's', value: 5 },
  { suit: 's', value: 6 },
  { suit: 'p', value: 7 },
  { suit: 'p', value: 8 },
  { suit: 'p', value: 9 },
  { suit: 'z', value: 1 },
  { suit: 'z', value: 1 },
  { suit: 'z', value: 5 },
  { suit: 'z', value: 5 },
];

export const Table: React.FC = () => {
  const [hand, setHand] = useState<Tile[]>(INITIAL_HAND);
  const [discards, setDiscards] = useState<Tile[]>([]);
  const [lastDrawn, setLastDrawn] = useState<Tile | null>({ suit: 'z', value: 7 });

  const handleDiscard = (index: number) => {
    // 必须先摸牌（有14张牌）才能打牌
    if (!lastDrawn) return;

    const combinedHand = [...hand, lastDrawn];
    const tile = combinedHand[index];
    
    if (!tile) return;

    let newHand = [...hand];
    if (index === hand.length) {
      // Discarding the drawn tile
      setLastDrawn(null);
    } else {
      // Discarding from the hand
      newHand.splice(index, 1);
      newHand.push(lastDrawn);
      setLastDrawn(null);
    }
    
    newHand.sort((a, b) => {
        if (a.suit !== b.suit) return a.suit.localeCompare(b.suit);
        return a.value - b.value;
    });

    setHand(newHand);
    setDiscards([...discards, tile]);
  };

  const drawTile = () => {
      if (lastDrawn) return;
      const suits: ('m' | 'p' | 's' | 'z')[] = ['m', 'p', 's', 'z'];
      const suit = suits[Math.floor(Math.random() * suits.length)];
      const value = suit === 'z' ? Math.floor(Math.random() * 7) + 1 : Math.floor(Math.random() * 9) + 1;
      setLastDrawn({ suit, value });
  };

  return (
    <div className="relative flex h-screen w-full items-center justify-center bg-[radial-gradient(circle,_var(--color-table-green)_0%,_var(--color-table-shadow)_100%)] overflow-hidden font-sans text-white">
      <WaterBackground />
      
      {/* Dora Indicator (Top Left) */}
      <div className="absolute left-8 top-8 z-20 flex flex-col items-start rounded-2xl border-2 border-ui-border bg-black/40 p-4 shadow-lg backdrop-blur-md">
        <div className="mb-2 text-[14px] font-bold text-white opacity-90 drop-shadow-sm">ドラ表示牌</div>
        <div className="flex gap-1">
          <MahjongTile tile={{ suit: 'm', value: 5 }} size="sm" />
          <MahjongTile tile={{ suit: 'z', value: 1 }} size="sm" isFaceDown />
          <MahjongTile tile={{ suit: 'z', value: 1 }} size="sm" isFaceDown />
          <MahjongTile tile={{ suit: 'z', value: 1 }} size="sm" isFaceDown />
          <MahjongTile tile={{ suit: 'z', value: 1 }} size="sm" isFaceDown />
        </div>
      </div>

      {/* Center HUD */}
      <div className="z-10 flex h-[200px] w-[280px] flex-col items-center justify-center rounded-3xl border-4 border-ui-border bg-ui-glass p-4 shadow-[0_10px_30px_rgba(0,0,0,0.2)] backdrop-blur-md">
        <div className="mb-6 text-3xl font-black tracking-[2px] text-white drop-shadow-md">✨ 東 1 局 ✨</div>
        
        {/* Stats */}
        <div className="flex w-full items-center justify-around">
          <div className="flex flex-col items-center">
            <div className="text-[14px] font-bold opacity-90 drop-shadow-sm">残り</div>
            <div className="font-mono text-3xl font-black drop-shadow-md">69</div>
          </div>
          <div className="flex flex-col items-center gap-2">
            <div className="rounded-full bg-black/20 px-4 py-1 text-[14px] font-bold opacity-90">0 本場</div>
            <div className="rounded-full bg-black/20 px-4 py-1 text-[14px] font-bold opacity-90">0 供託</div>
          </div>
        </div>
      </div>

      {/* Player Info Tags */}
      <div className="absolute bottom-[110px] left-1/2 flex -translate-x-1/2 gap-4 rounded-full border-2 border-ui-border bg-black/40 px-5 py-2 text-base font-bold shadow-lg backdrop-blur-sm">
        <span>🐶 あなた (東)</span>
        <span className="text-points-gold drop-shadow-sm">25,000</span>
      </div>
      <div className="absolute right-[100px] top-1/2 flex -translate-y-1/2 gap-4 rounded-full border-2 border-ui-border bg-black/40 px-5 py-2 text-base font-bold shadow-lg backdrop-blur-sm">
        <span>🐱 田中</span>
        <span className="text-points-gold drop-shadow-sm">25,000</span>
      </div>
      <div className="absolute left-1/2 top-[110px] flex -translate-x-1/2 gap-4 rounded-full border-2 border-ui-border bg-black/40 px-5 py-2 text-base font-bold shadow-lg backdrop-blur-sm">
        <span>🐻 佐藤</span>
        <span className="text-points-gold drop-shadow-sm">25,000</span>
      </div>
      <div className="absolute left-[100px] top-1/2 flex -translate-y-1/2 gap-4 rounded-full border-2 border-ui-border bg-black/40 px-5 py-2 text-base font-bold shadow-lg backdrop-blur-sm">
        <span>🐼 鈴木</span>
        <span className="text-points-gold drop-shadow-sm">25,000</span>
      </div>

      {/* Discard Piles (Rivers) */}
      <div className="absolute bottom-[200px] left-1/2 -translate-x-1/2">
        <River discards={discards} />
      </div>
      <div className="absolute left-[160px] top-1/2 -translate-y-1/2 rotate-90">
        <River discards={[]} />
      </div>
      <div className="absolute left-1/2 top-[200px] -translate-x-1/2 rotate-180">
        <River discards={[]} />
      </div>
      <div className="absolute right-[160px] top-1/2 -translate-y-1/2 -rotate-90">
        <River discards={[]} />
      </div>

      {/* Player Hands */}
      <div className="absolute bottom-[30px] left-1/2 -translate-x-1/2">
        <Hand 
          tiles={lastDrawn ? [...hand, lastDrawn] : hand} 
          isCurrentPlayer 
          onTileClick={handleDiscard} 
        />
      </div>
      <div className="absolute left-[-20px] top-1/2 -translate-y-1/2 opacity-50">
        <Hand tiles={Array(13).fill({ suit: 'z', value: 1 })} orientation="left" />
      </div>
      <div className="absolute top-4 left-1/2 -translate-x-1/2 opacity-50">
        <Hand tiles={Array(13).fill({ suit: 'z', value: 1 })} orientation="top" />
      </div>
      <div className="absolute right-[-20px] top-1/2 -translate-y-1/2 opacity-50">
        <Hand tiles={Array(13).fill({ suit: 'z', value: 1 })} orientation="right" />
      </div>

      {/* Action Buttons */}
      <div className="absolute bottom-[40px] right-[40px] flex flex-col gap-[12px]">
        <button 
          onClick={drawTile}
          disabled={!!lastDrawn}
          className="w-[110px] rounded-full border-4 border-white bg-cyan-400 p-3 font-black uppercase tracking-wider text-white shadow-[0_6px_0_#0891b2] transition-all hover:-translate-y-1 hover:shadow-[0_8px_0_#0891b2] active:translate-y-1 active:shadow-[0_0px_0_#0891b2] disabled:opacity-50 disabled:hover:translate-y-0 disabled:hover:shadow-[0_6px_0_#0891b2]"
        >
          引く
        </button>
        <button className="w-[110px] rounded-full border-4 border-white bg-pink-500 p-3 font-black uppercase tracking-wider text-white shadow-[0_6px_0_#be185d] transition-all hover:-translate-y-1 hover:shadow-[0_8px_0_#be185d] active:translate-y-1 active:shadow-[0_0px_0_#be185d]">
          ロン！
        </button>
        <button className="w-[110px] rounded-full border-4 border-white bg-amber-400 p-3 font-black uppercase tracking-wider text-white shadow-[0_6px_0_#d97706] transition-all hover:-translate-y-1 hover:shadow-[0_8px_0_#d97706] active:translate-y-1 active:shadow-[0_0px_0_#d97706]">
          リーチ
        </button>
        <button className="w-[110px] rounded-full border-4 border-white bg-indigo-400 p-3 font-black uppercase tracking-wider text-white shadow-[0_6px_0_#4338ca] transition-all hover:-translate-y-1 hover:shadow-[0_8px_0_#4338ca] active:translate-y-1 active:shadow-[0_0px_0_#4338ca]">
          ポン
        </button>
      </div>

      {/* Dora Indicator Card (Optional, keeping it but styled Sleek) */}
      <Card className="absolute right-8 top-8 w-48 border-ui-border bg-ui-glass p-4 text-white backdrop-blur-md">
        <h2 className="mb-2 text-sm font-bold uppercase tracking-wider opacity-70">山牌</h2>
        <div className="flex justify-between font-mono text-lg">
          <span>残り 70 枚</span>
        </div>
      </Card>
    </div>
  );
};
