/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Suit = 'm' | 'p' | 's' | 'z'; // Manzu, Pinzu, Souzu, Zihai (Honors)

export interface Tile {
  suit: Suit;
  value: number; // 1-9 for m,p,s; 1-7 for z (1-4: East, South, West, North; 5-7: White, Green, Red)
  isRed?: boolean; // Aka-dora
}

export type Wind = 'E' | 'S' | 'W' | 'N';

export interface Player {
  id: string;
  name: string;
  score: number;
  wind: Wind;
  hand: Tile[];
  discards: Tile[];
  melds: Meld[];
  isDealer: boolean;
}

export interface Meld {
  type: 'chi' | 'pon' | 'kan';
  tiles: Tile[];
  fromPlayerId?: string;
}

export interface GameState {
  round: Wind;
  roundNumber: number; // 1-4
  honba: number;
  riichiSticks: number;
  dora: Tile[];
  wallCount: number;
  currentPlayerIndex: number;
  players: Player[];
}
